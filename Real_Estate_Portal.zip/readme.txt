@Login Info

Username: Nibir
Password: nibir
Project Features:
Task 1: User/Guest can book property using their credit card and login info.
Task 2: User/Guest can post an ad which can also be removed or updated.
